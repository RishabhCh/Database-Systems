INSERT INTO continent VALUES ('South America','17840000');
INSERT INTO continent VALUES ('Europe','10523000');
INSERT INTO continent VALUES ('Asia','44614500');
INSERT INTO continent VALUES ('Australia/Oceania','9000000');
INSERT INTO continent VALUES ('North America','24709000');
INSERT INTO continent VALUES ('Africa','30221500');
